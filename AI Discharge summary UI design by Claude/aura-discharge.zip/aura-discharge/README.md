# Aura — AI Discharge Summary Platform

Production-ready landing page + live demo for the Aura discharge summary AI product.

## Files
- `index.html` — Full landing page with interactive demo
- `vercel.json` — Vercel deployment config
- `netlify.toml` — Netlify deployment config

---

## Deploy to Vercel (recommended — 2 minutes)

1. Go to https://vercel.com and sign up / log in (free)
2. Click **"Add New Project"**
3. Choose **"Upload"** (or connect GitHub if you've pushed this folder)
4. Drag and drop this entire folder
5. Click **Deploy**
6. Your live URL: `https://aura-discharge.vercel.app`

### Via Vercel CLI (fastest)
```bash
npm i -g vercel
cd aura-discharge
vercel
```
Follow the prompts. Live in ~60 seconds.

---

## Deploy to Netlify (drag & drop — 1 minute)

1. Go to https://app.netlify.com
2. Scroll to **"Deploy manually"** section at the bottom
3. Drag the `aura-discharge` folder into the drop zone
4. Done — Netlify gives you a live URL instantly
5. Rename site under Site Settings → `aura-discharge.netlify.app`

### Via Netlify CLI
```bash
npm i -g netlify-cli
cd aura-discharge
netlify deploy --prod --dir .
```

---

## Deploy to GitHub Pages (free, permanent)

1. Create a new repo on https://github.com — name it `aura-discharge`
2. Push this folder:
```bash
git init
git add .
git commit -m "Initial deploy"
git remote add origin https://github.com/YOUR_USERNAME/aura-discharge.git
git push -u origin main
```
3. Go to repo **Settings → Pages**
4. Source: **Deploy from branch** → Branch: `main` → Folder: `/ (root)`
5. Save — live at `https://YOUR_USERNAME.github.io/aura-discharge`

---

## Custom domain (any platform)

After deploying, add your custom domain (e.g. `aura.health`) in the platform's domain settings.
They'll give you a CNAME record to add to your DNS provider.
